public class ArrayStackADTTest {
    public static void fill(ArrayStackADT stack, String prefix) {
        for (int i = 0; i < 10; i++) {
            ArrayStackADT.push(stack, prefix + i);
        }
    }

    public static void dump(ArrayStackADT stack) {
        while (!ArrayStackADT.isEmpty(stack)) {
            System.out.println(
                ArrayStackADT.size(stack) + " " +
                ArrayStackADT.peek(stack) + " " +
                ArrayStackADT.pop(stack)
            );
        }
    }

    public static void main(String[] args) {
        ArrayStackADT stack1 = ArrayStackADT.create();
        ArrayStackADT stack2 = ArrayStackADT.create();
        fill(stack1, "s1_");
        fill(stack2, "s2_");
        dump(stack1);
        dump(stack2);
    }
}
