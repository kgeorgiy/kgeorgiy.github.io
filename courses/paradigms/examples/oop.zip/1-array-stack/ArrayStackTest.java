public class ArrayStackTest {
    public static void fill(ArrayStack stack, String prefix) {
        for (int i = 0; i < 10; i++) {
            stack.push(prefix + i);
        }
    }

    public static void dump(ArrayStack stack) {
        while (!stack.isEmpty()) {
            System.out.println(stack.size() + " " + stack.pop());
        }
    }

    public static void main(String[] args) {
        ArrayStack stack1 = new ArrayStack();
        ArrayStack stack2 = new ArrayStack();
        fill(stack1, "s1_");
        fill(stack2, "s2_");
        dump(stack1);
        dump(stack2);
    }
}
