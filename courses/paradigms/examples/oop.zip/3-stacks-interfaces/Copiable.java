public interface Copiable {
    /*public*/ Copiable makeCopy();
}
