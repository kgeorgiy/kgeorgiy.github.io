package lambda;

import java.io.IOException;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public enum RunExamples {
    ;

    public static void main(final String... args) throws IOException {
//        System.out.println("=== Lambdas");
//        Lambdas.main(args);
//
//        System.out.println("=== Log");
//        Log.main("Hello", "world");
//
//        System.out.println("=== IOSupplier");
//        IOSupplier.main("input.txt");
//
        System.out.println("=== Streams");
        Words.main(args);

        System.out.println("=== Implementation");
        Implementation.main(args);
    }
}
