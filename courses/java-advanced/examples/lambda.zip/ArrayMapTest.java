package lambda;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public final class ArrayMapTest {
    public static void main(final String... args) {
        final Map<String, Integer> map = new ArrayMap<>();
        map.put("Hello", 1);
        map.put("world", 2);
        map.put("!", 3);
        System.out.println(map.entrySet().stream().map(Map.Entry::toString).collect(Collectors.joining(", ")));
    }
}
