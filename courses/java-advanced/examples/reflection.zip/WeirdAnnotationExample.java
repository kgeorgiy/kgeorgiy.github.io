public class WeirdAnnotationExample implements Override {
    @Override
    public Class<? extends java.lang.annotation.Annotation> annotationType() {
        return Override.class;
    }


    public static void main(String[] args) {
        System.out.println(new WeirdAnnotationExample());
    }
}