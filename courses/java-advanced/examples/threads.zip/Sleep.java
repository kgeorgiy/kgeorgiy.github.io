package threads;

public final class Sleep {
    private Sleep() {
    }

    public static void main(final String[] args) throws InterruptedException {
        Thread.sleep(100_000);
    }
}
