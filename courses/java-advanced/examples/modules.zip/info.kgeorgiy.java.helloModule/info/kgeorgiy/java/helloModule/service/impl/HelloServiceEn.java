package info.kgeorgiy.java.helloModule.service.impl;

import info.kgeorgiy.java.helloModule.service.HelloService;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public class HelloServiceEn implements HelloService {
    @Override
    public void sayHello(final String to) {
        System.out.format("        Hello, %s%n", to);
    }
}
