package info.kgeorgiy.java.helloModule.service;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public interface HelloService {
    void sayHello(final String to);
}
