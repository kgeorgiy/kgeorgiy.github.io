#!/bin/bash -eu
__testApp/bin/java \
    --module info.kgeorgiy.java.testModule/info.kgeorgiy.java.testModule.Main
