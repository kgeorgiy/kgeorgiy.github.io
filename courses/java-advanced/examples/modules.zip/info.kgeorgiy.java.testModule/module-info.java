module info.kgeorgiy.java.testModule {
    requires info.kgeorgiy.java.helloModule;

    uses info.kgeorgiy.java.helloModule.service.HelloService;
}