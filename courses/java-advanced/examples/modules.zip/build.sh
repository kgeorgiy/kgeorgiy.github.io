#!/bin/bash -eu

rm -rf __modules

JAVAC_OPTIONS="-d __modules --module-path __modules --module-source-path ."

find info.kgeorgiy.java.helloModule -name '*.java' > info.kgeorgiy.java.helloModule/__sources
javac $JAVAC_OPTIONS @info.kgeorgiy.java.helloModule/__sources

find info.kgeorgiy.java.testModule -name '*.java' > info.kgeorgiy.java.testModule/__sources
javac $JAVAC_OPTIONS @info.kgeorgiy.java.testModule/__sources
