#!/bin/bash
export CLASSPATH=..

java rmi.BankWebServer
