#!/bin/bash
java -cp .. rmi.Client $@
