package io;

import java.io.*;

/**
 * Copies {@code input.txt} to {@code output.txt} capitalizing all letters.
 * <p>
 * <em>Warning: This code violates exception handling principles.</em>
 *
 * @author Georgiy Korneev
 */
public final class ToUpperCase {
    /**
     * Copies {@code input.txt} to {@code output.txt} capitalizing all letters.
     * <p>
     * <em>Warning: This code violates exception handling principles.</em>
     *
     * @param args ignored.
     *
     * @throws IOException if an I/O error occurred.
     */
    public static void main(final String[] args) throws IOException {
        final Reader reader = new FileReader("input.txt");
        final Writer writer = new FileWriter("output.txt");
        int c = 0;
        while ((c = reader.read()) >= 0) {
            writer.write(Character.toUpperCase((char) c));
        }
        reader.close();
        writer.close();
    }
}
