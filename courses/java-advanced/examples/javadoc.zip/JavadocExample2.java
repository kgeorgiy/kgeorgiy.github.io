package javadoc;

public class JavadocExample2 {
    /**
     * Calculates factorial. For negative numbers returns {@code 1}.
     * {@link JavadocExample3 3rd example}.
     *
     * @param x a value
     * @return the factorial of {@code x}.
     * @see JavadocExample1
     */
    public double factorial(int x) {
        return (x <= 1) ? 1 : x * factorial(x - 1);
    }
}
