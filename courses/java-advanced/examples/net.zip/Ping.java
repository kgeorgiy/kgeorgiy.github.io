package net;

import java.net.*;
import java.io.*;

public class Ping {
    public static void main(String[] args) throws IOException {
        InetAddress address = InetAddress.getByName(args[0]);
        System.out.println("Pinging " + address);
        if (address.isReachable(1000)) {
            System.out.println("Ping OK");
        } else {
            System.out.println("Ping FAILED");
        }
    }
}